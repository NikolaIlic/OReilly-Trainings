INSERT INTO my_data_source
VALUES (6, 'incremental_John','9/6/2024 2:23:00 AM')

INSERT INTO my_data_source
VALUES (7, 'incremental_Mary','9/7/2024 9:01:00 AM')


SELECT *
FROM my_data_source


SELECT *
FROM watermark_table

