DROP TABLE IF EXISTS watermark_table;

CREATE TABLE watermark_table
(
    TableName varchar(255)
    , WatermarkValue DATETIME2(6)
);

