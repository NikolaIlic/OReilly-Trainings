--LAG
SELECT CustomerKey
    , OrderDate
    , SalesOrderNumber
    , LAG(SalesOrderNumber) OVER(PARTITION BY CustomerKey ORDER BY CustomerKey) AS PrevOrder
FROM aw_factinternetsales

--LEAD
SELECT CustomerKey
    , OrderDate
    , SalesOrderNumber
    , LEAD(SalesOrderNumber) OVER(PARTITION BY CustomerKey ORDER BY CustomerKey, OrderDate) AS NextOrder
FROM aw_factinternetsales

--FIRST_VALUE/LAST_VALUE
SELECT CustomerKey
    , OrderDate
    , SalesOrderNumber
    , FIRST_VALUE(SalesOrderNumber) OVER(PARTITION BY CustomerKey ORDER BY CustomerKey, OrderDate) AS FirstOrder
FROM aw_factinternetsales