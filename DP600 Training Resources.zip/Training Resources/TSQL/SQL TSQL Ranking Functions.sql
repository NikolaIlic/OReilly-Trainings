--ROW_NUMBER()
SELECT SalesOrderNumber
    , OrderDate
    , CustomerKey
    , ROW_NUMBER() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS rnm
FROM aw_factinternetsales
WHERE CustomerKey = 11330

--RANK()
SELECT SalesOrderNumber
    , OrderDate
    , CustomerKey
    , RANK() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS rnm
FROM aw_factinternetsales
WHERE CustomerKey = 11330

--DENSE_RANK
SELECT SalesOrderNumber
    , OrderDate
    , CustomerKey
    , DENSE_RANK() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS rnm
FROM aw_factinternetsales
WHERE CustomerKey = 11330

--H2H
SELECT SalesOrderNumber
    , OrderDate
    , CustomerKey
    , ROW_NUMBER() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS rnm
    , RANK() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS rnk
    , DENSE_RANK() OVER (PARTITION BY CustomerKey ORDER BY OrderDate) AS densernk
FROM aw_factinternetsales
WHERE CustomerKey = 11330