--Create table
DROP TABLE IF EXISTS dbo.Dup_Miss_Customers;

CREATE TABLE dbo.Dup_Miss_Customers (
    CustomerID VARCHAR(10),
    Name VARCHAR(50),
    Region VARCHAR(50),
    Spending FLOAT
);

INSERT INTO dbo.Dup_Miss_Customers (CustomerID, Name, Region, Spending)
VALUES 
('C001', 'Alice', 'North', 100.0),
('C002', 'Bob', NULL, 200.0),
('C003', 'Carol', 'South', NULL),
('C002', 'Bob', NULL, 200.0),  -- Duplicate
('C004', NULL, 'West', 300.0),
('C005', 'Eve', 'East', 150.0),
('C006', 'Frank', 'North', 100.0),
('C001', 'Alice', 'North', 100.0); -- Duplicate

-- Identify missing values
SELECT 
    SUM(CASE WHEN Name IS NULL THEN 1 ELSE 0 END) AS Missing_Name,
    SUM(CASE WHEN Region IS NULL THEN 1 ELSE 0 END) AS Missing_Region,
    SUM(CASE WHEN Spending IS NULL THEN 1 ELSE 0 END) AS Missing_Spending
FROM dbo.Dup_Miss_Customers;

-- Fill missing values
SELECT 
    CustomerID,
    ISNULL(Name, 'Unknown') AS Name,
    ISNULL(Region, 'Unknown') AS Region,
    ISNULL(Spending, 0.0) AS Spending
FROM dbo.Dup_Miss_Customers;

-- Drop rows with NULLs
SELECT *
FROM dbo.Dup_Miss_Customers
WHERE Name IS NOT NULL
  AND Region IS NOT NULL
  AND Spending IS NOT NULL;

-- Identify duplicates
SELECT CustomerID, Name, Region, Spending, COUNT(*) AS DuplicateCount
FROM dbo.Dup_Miss_Customers
GROUP BY CustomerID, Name, Region, Spending
HAVING COUNT(*) > 1;

-- Remove duplicates
WITH RankedCustomers AS (
    SELECT *, 
           ROW_NUMBER() OVER (
               PARTITION BY CustomerID, Name, Region, Spending 
               ORDER BY CustomerID) AS rn
    FROM dbo.Dup_Miss_Customers
)
SELECT CustomerID, Name, Region, Spending
FROM RankedCustomers
WHERE rn = 1;





